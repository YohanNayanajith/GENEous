<?php
$connection = mysqli_connect('localhost','root','','bloodgene');

//get report details
function report_detail()
{
    global $connection;
    if(isset($_POST['check_report']))
    { 
        if(!$connection)
        {
            die("Can't connection ".mysqli_error($connection));
        }
        $user_name = $_POST['user_name'];
        $haemoglobin = $_POST['haemoglobin'];
        $rbc = $_POST['rbc'];
        $pcv = $_POST['pcv'];
        $mcv = $_POST['mcv'];
        $mch = $_POST['mch'];
        $mchc = $_POST['mchc'];
        $wbc = $_POST['wbc'];
        $neutrophils = $_POST['neutrophils']; 
        $lymphocytes = $_POST['lymphocytes'];
        $eosinophils = $_POST['eosinophils'];
        $monocytes = $_POST['monocytes'];
        $basophils = $_POST['basophils'];
        
        $user_name = mysqli_real_escape_string($connection,$user_name);
        $haemoglobin = mysqli_real_escape_string($connection,$haemoglobin);
        $rbc = mysqli_real_escape_string($connection,$rbc);
        $pcv = mysqli_real_escape_string($connection,$pcv);
        $mcv = mysqli_real_escape_string($connection,$mcv);
        $mch = mysqli_real_escape_string($connection,$mch);
        $mchc = mysqli_real_escape_string($connection,$mchc);
        $wbc = mysqli_real_escape_string($connection,$wbc);
        $neutrophils = mysqli_real_escape_string($connection,$neutrophils);
        $lymphocytes = mysqli_real_escape_string($connection,$lymphocytes);
        $eosinophils = mysqli_real_escape_string($connection,$eosinophils);
        $monocytes = mysqli_real_escape_string($connection,$monocytes);
        $basophils = mysqli_real_escape_string($connection,$basophils);
        
        $query1 = "SELECT name FROM client ";
        $query1 .= "WHERE `name`= '$user_name'";

        $result1 = mysqli_query($connection,$query1);
        if(!$result1)
        {
            die(mysqli_error($connection));
        }
        
        if(mysqli_num_rows($result1) == 0)
        {
            echo "<div class='alert alert-danger'><strong>Please! Create a Account or Check Your Account Name</strong></div>";
            die(mysqli_error($connection));
        }else
        {
            $cid;
            $query2 = "SELECT cid FROM client ";
            $query2 .= "WHERE `name`= '$user_name'";
            
            $result2 = mysqli_query($connection,$query2);
            if(!$result2)
            {
                die(mysqli_error($connection));
            }

            while($row1=mysqli_fetch_assoc($result2))
            {
                /*if($password==$row2['cid'])
                {
                    header("Location: /BLOODgene");
                    //echo "<a href='C:/xampp/htdocs/BLOODgene/index.php' a>";
                    break;
                }*/
                $cid = $row1['cid'];
            }
            
            $query3 = "INSERT INTO fbc(RBC,WBC,PCV,MCV,MCH,MCHC,heamoglobin,basophils,neutrophils,lymphocytes,easinophils,monocytes,cid) ";
            $query3 .= "VALUES('$rbc','$wbc','$pcv','$mcv','$mch','$mchc','$haemoglobin','$basophils','$neutrophils','$lymphocytes','$eosinophils','$monocytes','$cid')";

            $result3 = mysqli_query($connection,$query3);
            
            if(!$result3)
            {
                echo "<div class='alert alert-danger'><strong>Can't process! Try again!</strong></div>";
                die(mysqli_error($connection));
            }else
            {
                echo "<div class='alert alert-success'><strong>Success! Please Wait!</strong></div>";
            }
        }
    }
}


