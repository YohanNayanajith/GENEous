<?php
$connection = mysqli_connect('localhost','root','','bloodgene');

//create account
function create_account()
{
    global $connection;
    if(isset($_POST['client_create']))
    { 
        if(!$connection)
        {
            die("Can't connection ".mysqli_error($connection));
        }
        $name = $_POST['client_name'];
        $age = $_POST['client_age'];
        $email = $_POST['client_email'];
        $password = $_POST['client_password'];
        $contact_number = $_POST['client_contact'];
        $re_password = $_POST['client_re_password'];

        $name = mysqli_real_escape_string($connection,$name);
        $email = mysqli_real_escape_string($connection,$email);
        $password = mysqli_real_escape_string($connection,$password);
        $re_password = mysqli_real_escape_string($connection,$re_password);
        
        if(!($password === $re_password))
        {
            echo "<div class='alert alert-danger'><strong>Incorrect Password! Try again!</strong></div>";
            die(mysqli_error($connection));
        }
        
        $hash_format = "$2y$10$";
        $salt = "iusesomecrazystrings222";

        $hashF_and_salt = $hash_format . $salt;
        $password = crypt($password,$hashF_and_salt);

        $query = "INSERT INTO client(name,age,email,password,contact_no) ";
        $query .= "VALUES('$name',$age,'$email','$password',$contact_number)";

        $result = mysqli_query($connection,$query);
        if(!$result)
        {
            die("Can't insert data! ".mysqli_error($connection));
            echo "<div class='alert alert-danger'><strong>Can't create! Try again!</strong></div>";
        }else
        {
            echo "<div class='alert alert-success'><strong>Success! Account create successful!</strong></div>";
        }
    }
}

//login account
function login_account()
{
    global $connection;
    if(isset($_POST['sign_in']))
    { 
        if(!$connection)
        {
            die("Can't connection ".mysqli_error($connection));
        }
        $user_name = $_POST['user_name'];
        $password = $_POST['user_pass'];
        
        $user_name = mysqli_real_escape_string($connection,$user_name);
        $password = mysqli_real_escape_string($connection,$password);
        
        $hash_format = "$2y$10$";
        $salt = "iusesomecrazystrings222";

        $hashF_and_salt = $hash_format . $salt;
        $password = crypt($password,$hashF_and_salt);

        $query1 = "SELECT name FROM client ";
        $query1 .= "WHERE `name`= '$user_name' ";
        
        $query2 = "SELECT password FROM client";

        $result1 = mysqli_query($connection,$query1);
        $result2 = mysqli_query($connection,$query2);
        if((!$result1 || !$result2) || mysqli_num_rows($result1) == 0)
        {
            echo "<div class='alert alert-danger'><strong>Can't Login! Try again!</strong></div>";
            die(mysqli_error($connection));
        }else
        {
            while($row2=mysqli_fetch_assoc($result2))
            {
                if($password==$row2['password'])
                {
                    header("Location: /BLOODgene");
                    //echo "<a href='C:/xampp/htdocs/BLOODgene/index.php' a>";
                    break;
                }
            }
        }
    }
}
