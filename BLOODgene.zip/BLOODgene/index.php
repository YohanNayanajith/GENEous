<?php include "header.php" ?>

<style>
    .form-create {
        background-image: url(Images/image8.jpg);
        background-size: cover;
    }
    .form-create h1 {
        font-weight: bold;
    }
    .form-create p {
        font-weight: bold;
    }
    

</style>
<body class="form-create">
<div class="container pt-4">
<div id="cover_page" class="carousel slide" data-ride="carousel">

  <ol class="carousel-indicators">
    <li data-target="#cover_page" data-slide-to="0" class="active"></li>
    <li data-target="#cover_page" data-slide-to="1"></li>
    <li data-target="#cover_page" data-slide-to="2"></li>
  </ol>
  
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="first-slide w-100" src="Images/image1.jpeg" alt="First slide" height="500px">
    </div>
    <div class="carousel-item">
      <img class="second-slide w-100" src="Images/image7.jpg" alt="Second slide" height="500px">
    </div>
    <div class="carousel-item">
      <img class="third-slide w-100" src="Images/image3.jpg" alt="Third slide" height="500px">
    </div>
  </div>
  
  <a class="carousel-control-prev" href="#cover_page" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#cover_page" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
        
</div>

<div class="detail pt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4">
                    <div class="detail_heading">
                        <center><h2>Full Blood Count</h2></center>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 pt-3">
                    <div class="full_blood_count">
                        <!--<figure><img src="" alt="img" /></figure>-->
                        <p>A complete blood count (CBC), also known as a full blood count (FBC), is a set of medical laboratory tests that provide information about the cells in a person's blood. The CBC indicates the counts of white blood cells, red blood cells and platelets, the concentration of hemoglobin, and the hematocrit (the volume percentage of red blood cells). The red blood cell indices, which indicate the average size and hemoglobin content of red blood cells, are also reported, and a white blood cell differential, which counts the different types of white blood cells, may be included. The CBC is often carried out as part of a medical assessment, and can be used to monitor health or diagnose diseases. <br><br>The results are interpreted by comparing them to reference ranges, which vary with gender and age. Conditions like anemia and thrombocytopenia are defined by abnormal complete blood count results. The red blood cell indices can provide information about the cause of a person's anemia such as iron deficiency and vitamin B12 deficiency, and the results of the white blood cell differential can help to diagnose viral, bacterial and parasitic infections and blood disorders like leukemia. Not all results falling outside of the reference range require medical intervention</p>
                        <center><a href="fbc_report.php" type="button" class="btn btn-danger">Check Report</a></center>
                    </div>
                </div>
            </div>
        </div>
    </div>


<!--footer-->
<div class="container pt-5">
    <?php include "footer.php" ?>
</div>

</body>

