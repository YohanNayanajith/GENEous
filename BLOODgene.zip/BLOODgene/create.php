<!--import php backend file -->
<?php include "header.php" ?>
<?php include "custom_php/create_account.php" ?>
<style>
    .form-create {
        background-image: url(Images/image8.jpg);
        background-size: cover;
    }
    .form-create h1 {
        font-weight: bold;
        /*text-shadow: 2px 2px black;*/
    }
    .form-create label {
        font-weight: bold;
    }

</style>
<body class="form-create">

<div class="container pt-4">
   <center><h1>Create your account</h1></center>
    <div class="mx-auto col-sm-6">
        
        <form action="create.php" method="post">
            <div class="form-group pt-3">
                <label for="client_name">Name with initials</label>
                <input type="text" class="form-control" name="client_name" id="client_name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label for="client_age">Your age</label>
                <input type="text" class="form-control" name="client_age" id="client_age" placeholder="Enter your age">
            </div>
            <div class="form-group">
                <label for="client_email">Your email</label>
                <input type="text" class="form-control" name="client_email" id="client_email" placeholder="Enter your email">
            </div>
            <div class="form-group">
                <label for="client_contact">Contact number</label>
                <input type="text" class="form-control" name="client_contact" id="client_contact" placeholder="Enter your contact number">
            </div>
            <div class="form-group">
                <label for="client_password">Password</label>
                <input type="password" class="form-control" name="client_password" id="client_password" placeholder="Enter your password">
            </div>
            <div class="form-group">
                <label for="client_re_password">Re-type Password</label>
                <input type="password" class="form-control" name="client_re_password" id="client_re_password" placeholder="Re-type your password">
            </div>

            <div class="form-group">
               <center>
                <input type="submit" class="btn btn-primary" value="Create Account" id="client_create" name="client_create">
                </center>
                
            </div>
        </form>
    </div>
</div>
<?php create_account() ?>
</body>

<!--footer-->
<div class="container pt-5">
    <?php include "footer.php" ?>
</div>


