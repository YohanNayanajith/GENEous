<style>
    
 @import url('https://fonts.googleapis.com/css?family=Rajdhani:300,400,500,600,700');
 @import url('https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');    
    
.footer {
     background-color: #032703;
     padding-bottom: 36px;
}
 .footer .blood-gene {
    margin-top: 45px;
}
 .footer .blood-gene h3 {
     color: #fff;
     font-size: 31px;
     line-height: 30px;
     display: block;
     padding-bottom: 25px;
     /*text-transform: uppercase;*/
     text-align: center;
     /*border: #ddd solid 1px;*/
     width: 676px;
     margin: 0 auto;
     padding: 25px 0;
     font-weight: bold;
     font-family:Poppins;
}
 .coa {
    color: #EF0000;
}
 .footer .Contact i a {
     border: #fff solid 1px;
     padding: 3% 11%;
     display: inline-block;
}
 .footer .Social h3 {
     color: #fff;
     font-size: 17px;
     line-height: 30px;
     display: block;
     padding-bottom: 25px;
     text-transform: uppercase;
}
 .pdn-top-30 {
    padding-top: 30px;
}
 ul.location_icon {
     list-style: none;
     margin: 0;
     padding: 0;
     width: 100%;
     float: left;
}
 ul.location_icon li {
     float: left;
     height: 70px;
     color: #fff;
     display: flex;
     flex-wrap: wrap;
     align-items: center;
}
 ul.location_icon li img {
    padding-right: 10px;
}
 ul.location_icon span {
    font-size: 17px;
     font-weight: 400;
}
 ul.socil_link {
     list-style: none;
     margin: 0;
     padding: 0;
     width: 100%;
     float: left;
}
 ul.socil_link li {
     float: left;
     padding-right: 22%;
     height: 70px;
     margin: 0 -1px 0 0;
     text-align: center;
     display: flex;
     justify-content: center;
     align-items: center;
}
 .copyright {
     background-color: #fff;
     padding: 10px 0px;
}
 .copyright p {
     color: #120f0f;
     font-size: 16px;
     text-align: center;
}
 .copyright a {
    color: #120f0f;
}
 .copyright a:hover {
    color: #EF0000;
}

</style>
       
<footer>
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                        <div class="blood-gene">
                            <h3>BLOOD<strong class="coa">gene</strong></h3>
                        </div>

                    </div>


                </div>
                <div class="row pdn-top-30">
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                        <ul class="location_icon">
                            <li> <img src="icon/placeholder.png"> <span>11/A,New Kandy Road<br>Colombo 07,Sri Lanka</span></li>


                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                        <ul class="location_icon">
                            <li> <img src="icon/tel.png"><span>+94112762765</span></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                        <ul class="location_icon">
                            <li> <img src="icon/gmail.png"><span>BLOODgene@gmail.com</span></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12">
                        <ul class="location_icon">
                            <li> <a href="#"><img src="icon/fb_new.png"></a></li>
                            <li> <a href="#"><img src="icon/twitter_new.png"></a></li>
                            <li> <a href="#"><img src="icon/linkedin_new.png"></a></li>
                            <li> <a href="#"><img src="icon/whatsapp_new.png"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <p><b>Copyright 2020 All Right Reserved By <a href="">GENEous</a></b></p>
            </div>
        </div>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<script src="js/plugin.js"></script>

<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>