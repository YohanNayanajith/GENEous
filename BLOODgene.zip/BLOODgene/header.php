<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>BLOODgene</title>
    <!--<link rel="stylesheet" href="style.css">-->
    <link rel="icon" href="Images/blood3.png" type="image/gif" />
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    
    
</head>

<body>
    
<div class="container pt-4">
<nav class="navbar navbar-expand-sm bg-dark navbar-dark justify-content-between sticky-top">
    <ul class="navbar-nav">
    
    <a class="navbar-brand" href="#">
        <img src="Images/blood3.png" width="30" height="30" alt="">
    </a>
    
    <li class="nav-item">
        <a class="nav-link active" href="index.php">Home</a>  <!--style="color:red"-->
    </li>
    <li class="nav-item px-2">
        <a class="nav-link active" href="">About Us</a>
    </li>
    <li class="nav-item px-2">
        <a class="nav-link active" href="">Contact Us</a>    
    </li>
    <li class="nav-item dropdown px-2">
        <a href="" class="nav-link dropdown-toggle active" data-toggle="dropdown">Reports</a>
        <div class="dropdown-menu">
            <a href="#" class="dropdown-item">Anticular antibody</a>
            <a href="#" class="dropdown-item">Blood chemistry study</a>
            <a href="#" class="dropdown-item">Blood lipid profile</a>
            <a href="#" class="dropdown-item">BNP testing</a>
            <a href="#" class="dropdown-item">Complement</a>
            <a href="#" class="dropdown-item">Creatinine</a>
            <a href="#" class="dropdown-item">C-reactive protein</a>
            <a href="#" class="dropdown-item">Erythrocyte sedimentation rate</a>
            <a href="#" class="dropdown-item">Fecal occult blood test</a>
            <a href="fbc_report.php" class="dropdown-item">Full blood count</a>
            <a href="#" class="dropdown-item">Generic studies</a>
            <a href="#" class="dropdown-item">Hematocrit</a>
            <a href="#" class="dropdown-item">Liver function test</a>
            <a href="#" class="dropdown-item">Peripheral blood smear</a>
            <a href="#" class="dropdown-item">Rheumatoid factor</a>
            <a href="#" class="dropdown-item">Sedimentation rate</a>
            
        </div>
    </li>
    
    <li class="nav-item px-2">
        <a class="nav-link active" href="Login/login.php">Login</a>    
    </li>
    <li class="nav-item px-2">
        <a class="nav-link active" href="">Contact Doctor</a>    
    </li>
    
    </ul>
    <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Search</button>
  </form>
</nav>
</div>
