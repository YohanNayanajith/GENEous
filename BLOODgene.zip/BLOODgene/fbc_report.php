<!--import php backend file -->
<?php include "header.php" ?>
<?php include "custom_php/reports.php" ?>
<style>
    .form-create {
        background-image: url(Images/image8.jpg);
        background-size: cover;
    }
    .form-create h1 {
        font-weight: bold;
    }
    .form-create label {
        font-weight: bold;
    }

</style>
<body class="form-create">


<div class="container pt-4">
   <center><h1>Enter your blood report</h1></center>
    <div class="mx-auto col-sm-6">
        
        <form action="fbc_report.php" method="post">
            <div class="form-group pt-3">
                <label for="user_name">Enter your name</label>
                <input type="text" class="form-control" name="user_name" id="user_name" placeholder="Enter your login name">
            </div>
            <div class="form-group pt-3">
                <label for="haemoglobin">Haemoglobin</label>
                <input type="text" class="form-control" name="haemoglobin" id="haemoglobin" placeholder="Enter your haemoglobin result">
            </div>
            <div class="form-group">
                <label for="rbc">RBC</label>
                <input type="text" class="form-control" name="rbc" id="rbc" placeholder="Enter your RBC result">
            </div>
            <div class="form-group">
                <label for="pcv">PCV</label>
                <input type="text" class="form-control" name="pcv" id="pcv" placeholder="Enter your PCV result">
            </div>
            <div class="form-group">
                <label for="mcv">MCV</label>
                <input type="text" class="form-control" name="mcv" id="mcv" placeholder="Enter your MCV result">
            </div>
            <div class="form-group pt-3">
                <label for="mch">MCH</label>
                <input type="text" class="form-control" name="mch" id="mch" placeholder="Enter your MCH result">
            </div>
            <div class="form-group pt-3">
                <label for="mchc">MCHC</label>
                <input type="text" class="form-control" name="mchc" id="mchc" placeholder="Enter your MCHC result">
            </div>
            <div class="form-group">
                <label for="wbc">WBC</label>
                <input type="text" class="form-control" name="wbc" id="wbc" placeholder="Enter your WBC result">
            </div>
            
            
            <div class="form-group">
                <label for="neutrophils">Neutrophils</label>
                <input type="text" class="form-control" name="neutrophils" id="neutrophils" placeholder="Enter your Neutrophils result">
            </div>
            <div class="form-group">
                <label for="lymphocytes">Lymphocytes</label>
                <input type="text" class="form-control" name="lymphocytes" id="lymphocytes" placeholder="Enter your Lymphocytes result">
            </div>
            <div class="form-group">
                <label for="eosinophils">Eosinophils</label>
                <input type="text" class="form-control" name="eosinophils" id="eosinophils" placeholder="Enter your Eosinophils result">
            </div>
            <div class="form-group">
                <label for="monocytes">Monocytes</label>
                <input type="text" class="form-control" name="monocytes" id="monocytes" placeholder="Enter your Monocytes result">
            </div>
            <div class="form-group">
                <label for="basophils">Basophils</label>
                <input type="text" class="form-control" name="basophils" id="basophils" placeholder="Enter your Basophils result">
            </div>

            <div class="form-group">
               <center>
                <input type="submit" class="btn btn-danger" value="Check Blood Report" id="check_report" name="check_report">
                </center>
                
            </div>
        </form>
    </div>
</div>
<?php report_detail() ?>
</body>
<!--footer-->
<div class="container pt-5">
    <?php include "footer.php" ?>
</div>